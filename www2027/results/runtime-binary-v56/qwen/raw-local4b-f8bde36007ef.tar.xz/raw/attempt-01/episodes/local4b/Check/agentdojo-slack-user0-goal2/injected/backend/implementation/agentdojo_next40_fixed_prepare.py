"""Separate source-selection gate for next40; original fixed maps unchanged.

The original first25 validator remains untouched. This derivative retains its
190-map, original-registry, fixture and metadata verification after replacing
only the prospective cohort-membership rule.
"""
import hashlib
import json
from pathlib import Path
import re
from www2027.agentdojo_runtime_prototype import sha256, validate_fixture_manifest
from www2027.agentdojo_candidate_prepare import canonical

NEXT_MEASUREMENT_SHA256 = "b4e00565904cd8a65aad408a8a77b0f046459661ccd0ab8bfdc418990a91e5ac"

def validate_candidate_fixed_inputs(assembly_dir, contexts_file, source_receipt, selection_plan):
    assembly_dir, contexts_file, source_receipt, selection_plan = map(Path, [assembly_dir, contexts_file, source_receipt, selection_plan])
    selection = json.loads(selection_plan.read_text())
    inputs = {}
    for name, record in selection["inputs"].items():
        path = Path(record["path"])
        if sha256(path.read_bytes()) != record["sha256"]:
            raise ValueError("Frozen selection input changed: " + name)
        inputs[name] = json.loads(path.read_text())
    if sha256(contexts_file.read_bytes()) != selection["inputs"]["contexts"]["sha256"] or sha256(source_receipt.read_bytes()) != selection["inputs"]["source_receipt"]["sha256"]:
        raise ValueError("Supplied contexts/source receipt differ from selection")
    bank_plan = inputs["source_measurement"]
    if sha256(Path(selection["inputs"]["source_measurement"]["path"]).read_bytes()) != NEXT_MEASUREMENT_SHA256:
        raise ValueError("Banking source-measurement plan changed")
    expected = [row["candidate_id"] for row in bank_plan["candidates"]
                if row["source_disposition"] == "source_facts_preserved_pending_normal_and_native_controls"]
    if selection["selected_candidate_ids"] != expected or len(expected) != 40:
        raise ValueError("Frozen next40 membership/order changed")
    if selection["historical_or_new_attack_outcomes_used"] is not False:
        raise ValueError("Selection must be source-based")
    bank_rows = {row["candidate_id"]: row for row in bank_plan["candidates"]}
    if any(bank_rows[cid]["all_required_normal_source_facts_preserved"] is not True for cid in expected):
        raise ValueError("Unresolved normal task entered next40")
    original_order = [row["candidate_id"] for row in inputs["original_plan"]["candidates"]
                      if row["candidate_id"] in set(expected)]
    if original_order != expected:
        raise ValueError("Banking selection reorders original190")
    plan_rows = {row["candidate_id"]: row for row in inputs["original_plan"]["candidates"]}
    source_rows = {row["candidate_id"]: row for row in inputs["source_receipt"]["rows"]}
    if set(source_rows) != set(plan_rows) or len(source_rows) != 190:
        raise ValueError("Source receipt does not cover exact190 plan")
    plan_sha = selection["inputs"]["original_plan"]["sha256"]
    if (inputs["contexts"]["plan_sha256"] != plan_sha or inputs["actual_registry"]["plan_sha256"] != plan_sha
            or inputs["source_receipt"]["selection_plan_sha256"] != plan_sha):
        raise ValueError("Plan/context/registry/source receipt do not share one frozen plan")
    context_by_candidate = {candidate: context for context in inputs["contexts"]["normal_contexts"] for candidate in context["candidate_ids"]}
    registry_by_context = {context["context_id"]: context for context in inputs["actual_registry"]["contexts"]}
    ordinals = {row["candidate_id"]: index for index, row in enumerate(inputs["original_plan"]["candidates"])}
    if [row["candidate_id"] for row in selection["candidates"]] != expected:
        raise ValueError("Selected row order differs from frozen candidate IDs")
    for row in selection["candidates"]:
        original = plan_rows[row["candidate_id"]]
        context = context_by_candidate[row["candidate_id"]]
        required = {"normal_context_id": context["context_id"], "original_plan_ordinal": ordinals[row["candidate_id"]],
            "suite": original["suite"], "user_task_id": original["user_task_id"], "goal_id": original["attacker_goal_id"],
            "normal_prompt_sha256": original["normal_prompt_sha256"],
            "catalog_sha256": registry_by_context[context["context_id"]]["catalog_sha256"],
            "fixed_map_file_sha256": source_rows[row["candidate_id"]]["fixed_map_file_sha256"]}
        if any(row.get(key) != value for key, value in required.items()):
            raise ValueError("Selected candidate metadata retargeted or changed")
    verified = {}
    for candidate_id, row in plan_rows.items():
        if not re.fullmatch(r"agentdojo-(banking|slack|travel|workspace)-user[0-9]+-goal[0-9]+", candidate_id):
            raise ValueError("Invalid candidate identifier")
        source = source_rows[candidate_id]
        folder = source_receipt.parent / candidate_id
        raw_map, raw_log = (folder / "injections.json").read_bytes(), (folder / "published-log.json").read_bytes()
        if sha256(raw_map) != source["fixed_map_file_sha256"] or sha256(raw_log) != row["source_log_sha256"] or sha256(raw_log) != source["source_log_sha256"]:
            raise ValueError("Original source bytes changed")
        git_blob = hashlib.sha1(b"blob " + str(len(raw_log)).encode() + b"\0" + raw_log).hexdigest()
        if git_blob != row["source_log_git_blob_sha1"] or git_blob != source["git_blob_sha1"]:
            raise ValueError("Original log Git blob mismatch")
        mapping, log = json.loads(raw_map), json.loads(raw_log)
        if mapping != log["injections"] or sha256(canonical(mapping)) != row["injection_map_sha256"]:
            raise ValueError("Fixed map differs from original log/plan")
        if (log["suite_name"], log["user_task_id"], log["injection_task_id"]) != (row["suite"], row["user_task_id"], row["attacker_goal_id"]):
            raise ValueError("Original source task identity mismatch")
        slots = {slot["id"]: slot for slot in row["slots"]}
        if set(mapping) != set(slots):
            raise ValueError("Original slot set changed")
        for slot, text in mapping.items():
            if not isinstance(text, str) or sha256(text.encode()) != slots[slot]["sha256"] or len(text.encode()) != slots[slot]["bytes"]:
                raise ValueError("Original payload string changed")
        if candidate_id in expected:
            verified[candidate_id] = {"map_path": str(folder / "injections.json"), "map_sha256": sha256(raw_map),
                "canonical_map_sha256": sha256(canonical(mapping)), "plan_row": row, "slots": list(slots.values())}
    manifest_path = assembly_dir / "assembly_manifest.json"
    manifest = json.loads(manifest_path.read_text())
    validate_fixture_manifest(assembly_dir / "fixtures", manifest)
    if sha256(Path(manifest["parent_clean_assembly_manifest"]).read_bytes()) != manifest["parent_clean_assembly_manifest_sha256"]:
        raise ValueError("Parent clean assembly changed")
    return {"verified": True, "selection": selection, "selection_sha256": sha256(selection_plan.read_bytes()),
        "source_receipt_sha256": sha256(source_receipt.read_bytes()), "context_manifest_sha256": sha256(contexts_file.read_bytes()),
        "assembly_manifest_sha256": sha256(manifest_path.read_bytes()), "assembly": manifest,
        "contexts": inputs["contexts"], "verified_sources": verified, "source_maps_verified": 190}
