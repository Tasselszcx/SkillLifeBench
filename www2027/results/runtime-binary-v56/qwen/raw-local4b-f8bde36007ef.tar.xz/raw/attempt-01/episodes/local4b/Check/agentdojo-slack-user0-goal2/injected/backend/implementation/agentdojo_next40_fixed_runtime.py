"""Verified original-registry candidate fixed-source runtime; host never unpickles."""
from __future__ import annotations

import base64
import dataclasses
import gzip
import io
import json
from pathlib import Path
import re
import shutil
import tempfile
import uuid

from www2027.agentdojo_runtime_prototype import PROFILE, compact_result, sha256, validate_fixture_manifest
from www2027.agentdojo_candidate_fixed_worker import MAX_DECOMPRESSED_BYTES
from www2027.agentdojo_next40_fixed_prepare import validate_candidate_fixed_inputs
from www2027.isolated_executor import IsolatedExecutor


def canonical_bytes(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()


@dataclasses.dataclass(frozen=True)
class CandidateFixedStateHandle:
    runtime_id: str
    receipt_id: str
    receipt_sha256: str
    state_sha256: str
    context_id: str
    sequence: int
    initial_state_sha256: str
    parent_receipt_sha256: str | None
    condition: str
    source_map_sha256: str
    selection_plan_sha256: str


@dataclasses.dataclass(frozen=True)
class Transition:
    handle: CandidateFixedStateHandle | None
    receipt_path: Path
    result: dict


def verified_capture(result, filename, metadata):
    """The outside supervisor's size and complete digest are authoritative."""
    record = result["files"][filename]
    if (metadata["path"] != filename or record.get("kind") != "file"
            or record.get("base64_truncated") is not False
            or record.get("sha256_complete") is not True
            or record["size"] > PROFILE.capture_bytes):
        raise ValueError("Incomplete or oversized supervisor capture")
    payload = base64.b64decode(record["base64"], validate=True)
    if len(payload) != record["size"] or sha256(payload) != record["sha256"]:
        raise ValueError("Supervisor capture size/hash mismatch")
    if metadata["sha256"] != record["sha256"] or metadata["size"] != record["size"]:
        raise ValueError("Worker artifact metadata mismatch")
    return payload


def decode_audit_json(payload, metadata):
    """Only JSON audit snapshots are decoded on the host, with an output cap."""
    with gzip.GzipFile(fileobj=io.BytesIO(payload)) as stream:
        raw = stream.read(MAX_DECOMPRESSED_BYTES + 1)
    if (len(raw) > MAX_DECOMPRESSED_BYTES or len(raw) != metadata["uncompressed_bytes"]
            or sha256(raw) != metadata["uncompressed_sha256"]):
        raise ValueError("Audit JSON decompression bound/hash mismatch")
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("Audit environment must be a JSON object")
    return raw, value


class AgentDojoNext40FixedRuntime:
    """One host session, fresh OS sandbox for each init/tool/score operation.

    CandidateFixedStateHandle is session scoped and never model controlled. Models must receive
    only catalog/prompt and formatted tool results, never harness_only or state.
    """

    def __init__(self, assembly_dir: Path, contexts_file: Path, source_receipt: Path, selection_plan: Path, output_dir: Path):
        self.assembly = Path(assembly_dir)
        self.output = Path(output_dir)
        self.output.mkdir(parents=True, exist_ok=False)
        self.runtime_id = uuid.uuid4().hex
        self.source_receipt = Path(source_receipt)
        self.selection_plan = Path(selection_plan)
        self.validated_inputs = validate_candidate_fixed_inputs(assembly_dir, contexts_file, source_receipt, selection_plan)
        self.selection_sha = self.validated_inputs["selection_sha256"]
        self.source_receipt_sha = self.validated_inputs["source_receipt_sha256"]
        self.sources = self.validated_inputs["verified_sources"]
        self._public_bindings = {}
        self.manifest_path = self.assembly / "assembly_manifest.json"
        self.fixture_manifest = json.loads(self.manifest_path.read_text())
        self.fixture_manifest_sha = sha256(self.manifest_path.read_bytes())
        self.fixtures = self.assembly / "fixtures"
        validate_fixture_manifest(self.fixtures, self.fixture_manifest)
        self.contexts_file = Path(contexts_file)
        self.context_manifest_sha = sha256(self.contexts_file.read_bytes())
        contexts = json.loads(self.contexts_file.read_text())
        normal_contexts = {row["context_id"]: row for row in contexts["normal_contexts"]}
        if len(normal_contexts) != 95 or contexts["candidate_count"] != 190:
            raise ValueError("Only the frozen95 normal contexts are allowed")
        self.contexts = {}
        for row in self.validated_inputs["selection"]["candidates"]:
            base = normal_contexts[row["normal_context_id"]]
            self.contexts[row["candidate_id"]] = {**base, "context_id": row["candidate_id"],
                "normal_context_id": row["normal_context_id"], "candidate_ids": [row["candidate_id"]],
                "goal_ids": [row["goal_id"]], "expected_catalog_sha256": row["catalog_sha256"]}
        self.plan_path = Path(contexts["plan_path"])
        self.plan_sha = contexts["plan_sha256"]
        if sha256(self.plan_path.read_bytes()) != self.plan_sha:
            raise ValueError("Frozen190 plan changed")
        self.worker = Path(__file__).with_name("agentdojo_candidate_fixed_worker.py").read_text()
        self.worker_sha = sha256(self.worker.encode())
        self._issued = {}
        self._next_id = 0
        manifest = {
            "runtime_id": self.runtime_id, "format_version": 1,
            "assembly_manifest_path": str(self.manifest_path), "assembly_manifest_sha256": self.fixture_manifest_sha,
            "contexts_file": str(self.contexts_file), "context_manifest_sha256": self.context_manifest_sha,
            "plan_path": str(self.plan_path), "plan_sha256": self.plan_sha,
            "selection_plan": str(self.selection_plan), "selection_plan_sha256": self.selection_sha,
            "source_receipt": str(self.source_receipt), "source_receipt_sha256": self.source_receipt_sha,
            "selected_candidate_ids": list(self.contexts), "source_maps_verified": 190,
            "input_validator_sha256": sha256(Path(__file__).with_name("agentdojo_next40_fixed_prepare.py").read_bytes()),
            "worker_sha256": self.worker_sha, "host_runtime_sha256": sha256(Path(__file__).read_bytes()),
            "executor_sha256": sha256(Path(__file__).with_name("isolated_executor.py").read_bytes()),
            "sandbox_bootstrap_sha256": sha256(Path(__file__).with_name("_sandbox_worker.py").read_bytes()),
            "limits": dataclasses.asdict(PROFILE), "max_decompressed_bytes": MAX_DECOMPRESSED_BYTES,
            "opaque_state_format": "gzip(pickle protocol 5); decoded only in contained worker",
            "host_state_handling": "Only verified byte transport. No pickle loads/imported upstream environment on host.",
            "scope": "Frozen next40 source-selected runtime; normal-reference readiness only until separate target/utility gates pass. No model requests or payload generation in this module; readiness controls are separate and do not admit cases.",
            "arguments_contract": "Raw request, original list-normalized input, actual tool-entry deep copy, and post-call argument mutation are distinct audit fields.",
        }
        (self.output / "runtime_manifest.json").write_bytes(canonical_bytes(manifest))
        snapshot = self.output / "implementation"
        snapshot.mkdir()
        for source in [Path(__file__), Path(__file__).with_name("agentdojo_candidate_fixed_worker.py"),
                       Path(__file__).with_name("agentdojo_next40_fixed_prepare.py")]:
            (snapshot / source.name).write_bytes(source.read_bytes())
        self.executor = IsolatedExecutor(PROFILE)

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.executor.close()

    def _load_handle(self, handle):
        if not isinstance(handle, CandidateFixedStateHandle) or handle.runtime_id != self.runtime_id:
            raise ValueError("Unknown or cross-runtime handle")
        if not re.fullmatch(r"[0-9]{6}", handle.receipt_id):
            raise ValueError("Invalid receipt identifier")
        if self._issued.get(handle.receipt_id) != handle.receipt_sha256:
            raise ValueError("Receipt was not issued by this host session")
        directory = self.output / "receipts" / handle.receipt_id
        receipt_bytes = (directory / "receipt.json").read_bytes()
        if sha256(receipt_bytes) != handle.receipt_sha256:
            raise ValueError("Receipt hash mismatch")
        receipt = json.loads(receipt_bytes)
        expected = dataclasses.asdict(handle)
        del expected["receipt_sha256"]
        if receipt["handle_fields"] != expected:
            raise ValueError("Handle context_id/initial-state/sequence/lineage mismatch")
        payload = (directory / "state.bin.gz").read_bytes()
        artifact = receipt["artifact_integrity"]["state"]
        if (len(payload) != artifact["supervisor_size"] or len(payload) > PROFILE.capture_bytes
                or sha256(payload) != artifact["supervisor_sha256"] or sha256(payload) != handle.state_sha256):
            raise ValueError("Opaque state changed after supervisor capture")
        binding = receipt["worker_result"]["binding"]
        if (binding["context_id"] != handle.context_id or binding["initial_state_sha256"] != handle.initial_state_sha256
                or binding["sequence"] != handle.sequence or binding["parent_receipt_sha256"] != handle.parent_receipt_sha256
                or binding["condition"] != handle.condition or binding["source_map_sha256"] != handle.source_map_sha256
                or binding["selection_plan_sha256"] != handle.selection_plan_sha256
                or handle.selection_plan_sha256 != self.selection_sha
                or handle.source_map_sha256 != self.sources[handle.context_id]["map_sha256"]):
            raise ValueError("Receipt binding mismatch")
        return receipt, payload

    def initialize(self, context_id, condition):
        if context_id not in self.contexts:
            raise ValueError("Context is outside the frozen plan")
        if condition not in ("clean", "injected"):
            raise ValueError("Condition must be clean or injected")
        return self._invoke({"operation": "initialize", "context_id": context_id, "condition": condition, "sequence": 0,
                             "parent_receipt_sha256": None}, None)

    def step(self, handle, tool_name, arguments):
        if not isinstance(tool_name, str) or not isinstance(arguments, dict):
            raise TypeError("Tool name and JSON object arguments are required")
        # Ensure JSON-only transport; never accept executable nested objects.
        safe_arguments = json.loads(canonical_bytes(arguments))
        return self._from_handle(handle, {"operation": "step", "tool_name": tool_name, "arguments": safe_arguments})

    def score(self, handle, final_output, score_context="final_output"):
        if not isinstance(final_output, str):
            raise TypeError("Final output must be a string")
        return self._from_handle(handle, {"operation": "score", "final_output": final_output, "score_context": score_context})

    def _from_handle(self, handle, request):
        receipt, payload = self._load_handle(handle)
        request.update(context_id=handle.context_id, condition=handle.condition, sequence=handle.sequence + 1,
                       parent_receipt_sha256=handle.receipt_sha256,
                       input_state_sha256=handle.state_sha256,
                       input_state_uncompressed_sha256=receipt["worker_result"]["artifacts"]["state"]["uncompressed_sha256"],
                       expected_before_json_sha256=receipt["worker_result"]["artifacts"]["after"]["uncompressed_sha256"],
                       expected_before_types_sha256=receipt["worker_result"]["after_types_sha256"],
                       expected_binding=receipt["worker_result"]["binding"])
        return self._invoke(request, payload)

    def _invoke(self, request, state_payload):
        if sha256(self.manifest_path.read_bytes()) != self.fixture_manifest_sha:
            raise ValueError("Assembly manifest changed")
        if sha256(self.contexts_file.read_bytes()) != self.context_manifest_sha or sha256(self.plan_path.read_bytes()) != self.plan_sha:
            raise ValueError("Frozen context/plan changed")
        validate_fixture_manifest(self.fixtures, self.fixture_manifest)
        if sha256(self.selection_plan.read_bytes()) != self.selection_sha or sha256(self.source_receipt.read_bytes()) != self.source_receipt_sha:
            raise ValueError("Frozen selection/source receipt changed")
        source = self.sources[request["context_id"]]
        map_bytes = Path(source["map_path"]).read_bytes()
        if sha256(map_bytes) != source["map_sha256"]:
            raise ValueError("Original fixed map changed")
        request.update(worker_sha256=self.worker_sha, assembly_manifest_sha256=self.fixture_manifest_sha,
                       context_manifest_sha256=self.context_manifest_sha, context=self.contexts[request["context_id"]])
        request.update(selection_plan_sha256=self.selection_sha, source_receipt_sha256=self.source_receipt_sha,
                       source_map_sha256=source["map_sha256"],
                       effective_map_sha256=source["canonical_map_sha256"] if request["condition"] == "injected" else sha256(canonical_bytes({})),
                       argument_helper_sha256=self.fixture_manifest["argument_helper"]["staged_sha256"])
        request = json.loads(canonical_bytes(request))
        receipt_id = f"{self._next_id:06d}"
        self._next_id += 1
        directory = self.output / "receipts" / receipt_id
        directory.mkdir(parents=True)
        (directory / "request.json").write_bytes(canonical_bytes(request))
        exact_invocation = json.dumps({"code": self.worker, "callable_name": "execute_candidate",
            "args": [request], "kwargs": {}, "limits": dataclasses.asdict(PROFILE)}, ensure_ascii=False).encode()
        (directory / "invocation.json").write_bytes(exact_invocation)
        with tempfile.TemporaryDirectory(prefix="agentdojo-step-fixtures-") as temporary:
            stage = Path(temporary) / "fixtures"
            shutil.copytree(self.fixtures, stage)
            (stage / "fixed_injections.json").write_bytes(map_bytes)
            if state_payload is not None:
                (stage / "input_state.bin.gz").write_bytes(state_payload)
            try:
                result = self.executor.run(code=self.worker, callable_name="execute_candidate", args=[request], fixture_dir=stage)
            except Exception as error:
                result = {"status": "supervisor_error", "execution_error": type(error).__name__ + ": " + str(error),
                          "return_value": None, "files": {}, "changed_files": {}}
        receipt = {"request": request, "supervisor_result": compact_result(result),
                   "worker_result": result.get("return_value"), "artifact_integrity": {}, "handle_fields": None}
        handle = None
        if result["status"] == "ok":
            try:
                if sha256(exact_invocation) != result["invocation_sha256"]:
                    raise ValueError("Exact invocation bytes differ from supervisor invocation hash")
                value = result["return_value"]
                drift = value["operation_status"] == "pending_drift"
                binding = value.get("binding")
                if value["context_id"] != request["context_id"]:
                    raise ValueError("Worker context mismatch")
                if not drift and (binding["context_id"] != request["context_id"]
                        or binding["sequence"] != request["sequence"]
                        or binding["parent_receipt_sha256"] != request["parent_receipt_sha256"]
                        or binding["worker_sha256"] != self.worker_sha
                        or binding["assembly_manifest_sha256"] != self.fixture_manifest_sha
                        or binding["context_manifest_sha256"] != self.context_manifest_sha
                        or any(binding[key] != request[key] for key in ["condition", "selection_plan_sha256", "source_receipt_sha256",
                            "source_map_sha256", "effective_map_sha256", "argument_helper_sha256"])):
                    raise ValueError("Worker identity or sequence mismatch")
                if request["operation"] == "initialize" and not drift:
                    if binding["initial_state_sha256"] != value["artifacts"]["before"]["uncompressed_sha256"]:
                        raise ValueError("Initial state binding mismatch")
                    if sha256(canonical_bytes(value["catalog"])) != binding["catalog_sha256"]:
                        raise ValueError("Catalog binding mismatch")
                    public = (sha256(value["prompt"].encode()), binding["catalog_sha256"])
                    expected_context = self.contexts[request["context_id"]]
                    if public != (expected_context["expected_prompt_sha256"], expected_context["expected_catalog_sha256"]):
                        raise ValueError("Public prompt/catalog differ from frozen clean registry controls")
                    if request["context_id"] in self._public_bindings and self._public_bindings[request["context_id"]] != public:
                        raise ValueError("Public prompt/catalog differ between conditions")
                    self._public_bindings[request["context_id"]] = public
                elif not drift and request["operation"] != "initialize" and (value["artifacts"]["before"]["uncompressed_sha256"] != request["expected_before_json_sha256"]
                      or value["before_types_sha256"] != request["expected_before_types_sha256"]
                      or binding["initial_state_sha256"] != request["expected_binding"]["initial_state_sha256"]):
                    raise ValueError("Cross-step state or original-type continuity mismatch")
                for label, metadata in value["artifacts"].items():
                    filename = metadata["path"]
                    if not re.fullmatch(r"(?:before|after|source_resolution|predicate_(?:utility|goal_success)_(?:before|after))\.json\.gz|state\.bin\.gz", filename):
                        raise ValueError("Unexpected artifact filename")
                    payload = verified_capture(result, filename, metadata)
                    (directory / filename).write_bytes(payload)
                    record = result["files"][filename]
                    receipt["artifact_integrity"][label] = {**metadata, "supervisor_size": record["size"],
                                                           "supervisor_sha256": record["sha256"], "complete_capture": True}
                    if label != "state":
                        raw, _ = decode_audit_json(payload, metadata)
                        (directory / filename).with_suffix("").write_bytes(raw)
                receipt["scientific_status"] = "pending_drift" if drift else "runtime_observation_only"
                receipt["handle_fields"] = None if drift else {
                    "runtime_id": self.runtime_id, "receipt_id": receipt_id,
                    "state_sha256": receipt["artifact_integrity"]["state"]["supervisor_sha256"],
                    "context_id": binding["context_id"], "sequence": binding["sequence"],
                    "initial_state_sha256": binding["initial_state_sha256"],
                    "parent_receipt_sha256": binding["parent_receipt_sha256"],
                    "condition": binding["condition"], "source_map_sha256": binding["source_map_sha256"],
                    "selection_plan_sha256": binding["selection_plan_sha256"],
                }
            except (KeyError, ValueError, OSError, EOFError) as error:
                receipt["supervisor_result"]["status"] = "artifact_integrity_error"
                receipt["supervisor_result"]["execution_error"] = type(error).__name__ + ": " + str(error)
                receipt["handle_fields"] = None
        if receipt["handle_fields"] is None:
            reason = receipt.get("scientific_status") or receipt["supervisor_result"].get("execution_error") or receipt["supervisor_result"]["status"]
            receipt["scores"] = {key: {"status": "unknown", "value": None,
                "error": reason}
                for key in ["utility", "goal_success"]}
        receipt_bytes = canonical_bytes(receipt)
        receipt_path = directory / "receipt.json"
        receipt_path.write_bytes(receipt_bytes)
        if receipt["handle_fields"] is not None:
            receipt_sha = sha256(receipt_bytes)
            self._issued[receipt_id] = receipt_sha
            handle = CandidateFixedStateHandle(receipt_sha256=receipt_sha, **receipt["handle_fields"])
        return Transition(handle, receipt_path, receipt)
