"""Original-registry fixed-source runtime with source routes and isolated scoring."""

MAX_DECOMPRESSED_BYTES = 2 * 1024 * 1024
MAX_CAPTURE_BYTES = 64 * 1024


def observe_function_entry(function, invocations, encode):
    """Observe the original callable without replacing its argument objects."""
    import copy
    import json
    original = function.run
    dependency_names = set(function.dependencies)
    def wrapped(*args, **kwargs):
        visible = {key: value for key, value in kwargs.items() if key not in dependency_names}
        invocation = {"function": function.name,
            "normalized_before_execution": json.loads(encode(copy.deepcopy(visible))),
            "original_module": original.__module__, "original_qualified_name": original.__qualname__, "exception": None}
        invocations.append(invocation)
        try:
            return original(*args, **kwargs)
        except Exception as error:
            invocation["exception"] = type(error).__name__ + ": " + str(error)
            raise
        finally:
            invocation["post_call_arguments"] = json.loads(encode(copy.deepcopy(visible)))
    return wrapped


def evaluate_on_independent_copies(evaluator, pre, post, trace, snapshot, trace_snapshot):
    import copy
    actual_before = (snapshot(pre), snapshot(post), trace_snapshot(trace))
    local_pre, local_post, local_trace = copy.deepcopy(pre), copy.deepcopy(post), copy.deepcopy(trace)
    before = {"pre": snapshot(local_pre), "post": snapshot(local_post), "trace": trace_snapshot(local_trace)}
    try:
        value = evaluator(local_pre, local_post, local_trace)
        if not isinstance(value, bool):
            raise TypeError("Original predicate returned a non-bool")
        score = {"status": "known", "value": value, "error": None}
    except Exception as error:
        score = {"status": "unknown", "value": None, "error": type(error).__name__ + ": " + str(error)}
    after = {"pre": snapshot(local_pre), "post": snapshot(local_post), "trace": trace_snapshot(local_trace)}
    if (snapshot(pre), snapshot(post), trace_snapshot(trace)) != actual_before:
        raise RuntimeError("Predicate contaminated retained real input state")
    score["input_mutations"] = {key: before[key] != after[key] for key in before}
    score["retained_state_unchanged"] = True
    return score, before, after


def execute_candidate(request):
    import ast
    import copy
    import ctypes
    import gzip
    import hashlib
    import importlib
    import importlib.abc
    import inspect
    import io
    import json
    from pathlib import Path
    import pickle
    import sys

    def encoded(value):
        return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()

    def digest(data):
        return hashlib.sha256(data).hexdigest()

    def emit(filename, data):
        if len(data) > MAX_DECOMPRESSED_BYTES:
            raise ValueError("Uncompressed artifact bound exceeded")
        compressed = gzip.compress(data, mtime=0)
        if len(compressed) > MAX_CAPTURE_BYTES:
            raise ValueError("Complete artifact capture would exceed unchanged limit")
        Path(filename).write_bytes(compressed)
        return {"path": filename, "size": len(compressed), "sha256": digest(compressed),
                "uncompressed_bytes": len(data), "uncompressed_sha256": digest(data)}

    denied = ("agentdojo.attacks", "agentdojo.agent_pipeline.llms", "openai", "anthropic", "cohere", "google", "dotenv", "httpx", "requests", "litellm")

    class NoProviders(importlib.abc.MetaPathFinder):
        def find_spec(self, fullname, path=None, target=None):
            if any(fullname == name or fullname.startswith(name + ".") for name in denied):
                raise ImportError("Models/providers/attacks unavailable in clean controls")
            return None

    sys.meta_path.insert(0, NoProviders())
    sys.path[:0] = [str(path) for path in sorted(Path("/work").glob("*.whl"))]
    sys.path.insert(0, "/work/agentdojo_source.zip")
    native = [ctypes.CDLL("/work/native/" + name, mode=ctypes.RTLD_GLOBAL)
              for name in ("libgcc_s.so.1", "librt.so.1", "libpthread.so.0")]
    from agentdojo.task_suite.load_suites import get_suite
    from agentdojo.task_suite.task_suite import read_suite_file
    from agentdojo.base_tasks import BaseUserTask
    from agentdojo.functions_runtime import FunctionCall, FunctionsRuntime
    from agentdojo.agent_pipeline.tool_execution import tool_result_to_str
    from agentdojo.types import text_content_block_from_string
    from pydantic import BaseModel

    context = request["context"]
    condition = request["condition"]
    if condition not in ("clean", "injected") or len(context["goal_ids"]) != 1:
        raise ValueError("One frozen candidate and clean/injected condition required")
    raw_map = Path("fixed_injections.json").read_bytes()
    if digest(raw_map) != request["source_map_sha256"]:
        raise ValueError("Original fixed-map bytes changed")
    fixed_map = json.loads(raw_map)
    if not isinstance(fixed_map, dict) or not all(isinstance(key, str) and isinstance(value, str) for key, value in fixed_map.items()):
        raise ValueError("Original map must contain string slots")
    effective_map = fixed_map if condition == "injected" else {}
    if digest(encoded(effective_map)) != request["effective_map_sha256"]:
        raise ValueError("Effective map/condition binding mismatch")
    if digest(Path("original_is_string_list.py").read_bytes()) != request["argument_helper_sha256"]:
        raise ValueError("Original argument helper changed")
    from original_is_string_list import is_string_list
    from ast import literal_eval
    suite = get_suite(context["requested_benchmark_version"], context["suite"])
    suite.data_path = Path("/work/data") / context["suite"]
    user = suite.get_user_task_by_id(context["user_task_id"])
    if not isinstance(user, BaseUserTask):
        raise TypeError("Normal reference must resolve to BaseUserTask")
    goals = {name: suite.get_injection_task_by_id(name) for name in context["goal_ids"]}
    for goal in goals.values():
        goal.ground_truth = lambda *_args, **_kwargs: (_ for _ in ()).throw(RuntimeError("Goal actions are prohibited"))
    runtime = FunctionsRuntime(suite.tools)
    catalog = [{"name": function.name, "description": function.description,
                "parameters": function.parameters.model_json_schema()} for function in suite.tools]
    catalog_sha = digest(encoded(catalog))
    source_index = json.loads(Path("source_index.json").read_text())

    def tree_items(obj, path=(), ancestors=()):
        yield path, obj
        if id(obj) in ancestors:
            return
        chain = (*ancestors, id(obj))
        if isinstance(obj, BaseModel):
            for key in [*type(obj).model_fields, *type(obj).model_computed_fields]:
                yield from tree_items(getattr(obj, key), (*path, key), chain)
        elif isinstance(obj, dict):
            for key, value in obj.items():
                yield from tree_items(value, (*path, str(key)), chain)
        elif isinstance(obj, (list, tuple)):
            for index, value in enumerate(obj):
                yield from tree_items(value, (*path, str(index)), chain)

    def resolve(obj, path):
        for component in path:
            if isinstance(obj, BaseModel):
                obj = getattr(obj, component)
            else:
                obj = obj[int(component)] if isinstance(obj, (list, tuple)) else obj[component]
        return obj

    def source_bindings(environment):
        import yaml
        template = yaml.safe_load(read_suite_file(suite.name, "environment.yaml", suite.data_path))
        template_fields = list(tree_items(template))
        actual_nodes = list(tree_items(environment))
        bindings = {}
        for slot, payload in fixed_map.items():
            locations = [path for path, value in template_fields if isinstance(value, str) and "{" + slot + "}" in value]
            if not locations:
                raise ValueError("Fixed slot has no original template binding: " + slot)
            bindings[slot] = []
            for path in locations:
                value = resolve(environment, path)
                owner = resolve(environment, path[:-1])
                if not isinstance(value, str):
                    raise ValueError("Loaded source field is not a string")
                aliases = sorted([list((*other_path, path[-1])) for other_path, obj in actual_nodes if obj is owner])
                entity_path = next((path[:length] for length in range(len(path)-1, -1, -1)
                                    if isinstance(resolve(environment, path[:length]), BaseModel)), ())
                entity = resolve(environment, entity_path)
                entity_info = {key: getattr(entity, key) for key in ("id_", "name", "title")
                               if hasattr(entity, key) and isinstance(getattr(entity, key), str)}
                derived = []
                if type(owner).__name__ == "CloudDriveFile" and path[-1] == "content":
                    for alias in aliases:
                        derived.append({"path": [*alias[:-1], "size"], "value": owner.size,
                            "source_rule": "CloudDriveFile.compute_size -> len(content)", "matches_rule": owner.size == len(value),
                            "source_method": quote_callable(owner.compute_size)})
                bindings[slot].append({"path": list(path), "alias_paths": aliases, "alias_object_identity_verified": True, "value": value,
                    "sha256": digest(value.encode()), "bytes": len(value.encode()),
                    "raw_payload_sha256": digest(payload.encode()), "raw_payload_exact_in_loaded_field": payload in value,
                    "entity_path": list(entity_path), "entity_class": type(entity).__name__, "entity": entity_info,
                    "derived_fields": derived})
        return bindings

    def string_leaves(value):
        return [obj for _, obj in tree_items(value) if isinstance(obj, str)]

    def source_exposure(value, formatted, function_name, effective_arguments):
        import yaml
        strings = string_leaves(value)
        returned_ids = {id(obj) for _, obj in tree_items(value) if isinstance(obj, (BaseModel, dict, list, tuple))}
        decoded = {}
        if formatted is not None:
            for name, decoder in [("original_yaml_rendering", yaml.safe_load), ("original_python_repr", literal_eval)]:
                try:
                    decoded[name] = string_leaves(decoder(formatted))
                except Exception:
                    pass
        result = []
        for slot, payload in fixed_map.items():
            fields = []
            for field in bundle["bound_sources"][slot]:
                text = field["value"]
                route = None
                owner = resolve(bundle["environment"], field["path"][:-1])
                entity = resolve(bundle["environment"], field["entity_path"])
                if id(owner) in returned_ids or id(entity) in returned_ids:
                    route = "original_returned_object_identity"
                elif function_name in ("get_rating_reviews_for_hotels", "get_rating_reviews_for_restaurants", "get_rating_reviews_for_car_rental"):
                    name = field["entity"].get("name")
                    if isinstance(value, dict) and name in value and text and any(text in leaf for leaf in string_leaves(value[name])):
                        route = "original_named_review_result_key"
                elif function_name in ("get_webpage", "download_file") and field["path"][:2] == ["web", "web_content"]:
                    from agentdojo.default_suites.v1.tools.web import standardize_url
                    url = (effective_arguments or {}).get("url")
                    if isinstance(url, str) and standardize_url(url) == field["path"][2]:
                        route = "original_standardized_web_url"
                elif function_name == "read_file" and field["path"][:2] == ["filesystem", "files"]:
                    if (effective_arguments or {}).get("file_path") == field["path"][2]:
                        route = "original_virtual_file_path"
                present = bool(text) and any(text in leaf for leaf in strings)
                fields.append({key: field[key] for key in ["path", "alias_paths", "sha256", "bytes", "entity"]} | {
                    "empty_loaded_field": not bool(text), "value_present_in_structure": present,
                    "source_route": route, "structured_present": present and route is not None,
                    "rendered_exact_present": bool(text) and formatted is not None and text in formatted,
                    "rendered_decoded_presence": {name: bool(text) and any(text in leaf for leaf in leaves) for name, leaves in decoded.items()}})
            result.append({"slot": slot, "payload_sha256": digest(payload.encode()),
                "structured_exact_substring_present": bool(payload) and any(payload in leaf for leaf in strings),
                "rendered_exact_substring_present": bool(payload) and formatted is not None and payload in formatted,
                "rendered_decoded_presence": {name: bool(payload) and any(payload in leaf for leaf in leaves) for name, leaves in decoded.items()},
                "loader_bound_fields": fields,
                "method": "Loaded-field string presence plus original returned-object, named-review, web-URL or virtual-file route; raw substring presence alone does not attribute a slot."})
        return result

    def module_text(module_name):
        module = sys.modules[module_name]
        text = module.__loader__.get_source(module_name)
        if digest(text.encode()) != source_index[module_name]["sha256"]:
            raise ValueError("Actual class source differs from assembly index")
        return text

    def quote_callable(function):
        function = getattr(function, "__func__", function)
        text = module_text(function.__module__)
        lines, start = inspect.getsourcelines(function)
        segment = "".join(lines)
        if segment not in text:
            raise ValueError("Method source span does not match actual module")
        return {"module": function.__module__, "qualified_name": function.__qualname__,
                "module_sha256": digest(text.encode()), "line_start": start, "line_end": start + len(lines) - 1,
                "exact_source": segment, "source_segment_sha256": digest(segment.encode())}

    def task_description(task, is_user):
        cls = type(task)
        text = module_text(cls.__module__)
        lexical_name = cls.__qualname__.split(".")[-1]
        nodes = [node for node in ast.walk(ast.parse(text)) if isinstance(node, ast.ClassDef) and node.name == lexical_name]
        if len(nodes) != 1:
            raise ValueError("Actual class lexical source is ambiguous")
        node = nodes[0]
        segment = ast.get_source_segment(text, node)
        methods = ["ground_truth", "utility", "utility_from_traces", "init_environment"] if is_user else ["security", "security_from_traces"]
        description = {"task_id": task.ID, "module": cls.__module__, "class_name": cls.__name__, "qualified_name": cls.__qualname__,
            "source_file": source_index[cls.__module__]["path"], "source_file_sha256": digest(text.encode()),
            "class_span": {"line_start": node.lineno, "line_end": node.end_lineno,
                           "exact_source": segment, "sha256": digest(segment.encode())},
            "methods": {name: quote_callable(getattr(task, name)) for name in methods}, "captured_components": []}
        if is_user:
            function = user_method = getattr(task.ground_truth, "__func__", task.ground_truth)
            closure = dict(zip(function.__code__.co_freevars, function.__closure__ or ()))
            for name in ("user_task_1", "user_task_2"):
                if name in closure and isinstance(closure[name].cell_contents, BaseUserTask):
                    description["captured_components"].append(task_description(closure[name].cell_contents, True))
        else:
            constants, unreadable = {}, []
            for name, value in vars(cls).items():
                if name.startswith("__") or not name.isupper():
                    continue
                if name == "DIFFICULTY":
                    constants[name] = {"enum": type(value).__name__, "name": value.name}
                    continue
                try:
                    encoded(value)
                    constants[name] = value
                except (TypeError, ValueError):
                    unreadable.append(name)
            description.update(goal_text=task.GOAL, target_variables=constants,
                               unreadable_target_variables=unreadable, declared_target_variables_readable=not unreadable)
        return description

    def state_view(environment):
        return environment.model_dump(mode="json")

    def snapshot(environment):
        return encoded(state_view(environment))

    def trace_view(trace):
        return [call.model_dump(mode="json") for call in trace]

    def types(value):
        kind = type(value).__module__ + "." + type(value).__qualname__
        if isinstance(value, BaseModel):
            return [kind, {key: types(getattr(value, key)) for key in type(value).model_fields}]
        if isinstance(value, dict):
            return [kind, [[types(key), types(item)] for key, item in sorted(value.items(), key=lambda pair: str(pair[0]))]]
        if isinstance(value, (list, tuple)):
            return [kind, [types(item) for item in value]]
        return kind

    artifacts = {}
    source_resolution = None
    harness = None
    if request["operation"] == "initialize":
        source_resolution = {"context_id": context["context_id"], "suite_version": suite.benchmark_version,
            "normal_context_id": context["normal_context_id"], "candidate_id": context["context_id"], "condition": condition,
            "user_registry_version": max(version for version in suite._user_tasks[user.ID] if version <= suite.benchmark_version),
            "user": task_description(user, True),
            "goals": {name: {"registry_version": max(version for version in suite._injection_tasks[name] if version <= suite.benchmark_version),
                              **task_description(task, False)} for name, task in goals.items()},
            "actual_prompt": user.PROMPT, "actual_prompt_sha256": digest(user.PROMPT.encode()),
            "expected_prompt_sha256": context["expected_prompt_sha256"],
            "prompt_exact_match": user.PROMPT == context["expected_prompt"],
            "catalog_sha256": catalog_sha,
            "tool_sources": {function.name: quote_callable(function.run) for function in suite.tools},
            "registered_user_count": len(suite.user_tasks), "registered_goal_count": len(suite.injection_tasks),
            "imported_agentdojo_modules": sorted(name for name in sys.modules if name.startswith("agentdojo"))}
        artifacts["source_resolution"] = emit("source_resolution.json.gz", encoded(source_resolution))
        if not source_resolution["prompt_exact_match"]:
            return {"context_id": context["context_id"], "candidate_id": context["context_id"], "condition": condition,
                    "normal_context_id": context["normal_context_id"], "operation": "initialize", "operation_status": "pending_drift",
                    "artifacts": artifacts, "catalog": catalog, "prompt": user.PROMPT,
                    "source_resolution": {key: source_resolution[key] for key in ["actual_prompt_sha256", "expected_prompt_sha256", "prompt_exact_match"]},
                    "model_calls": 0, "injected_runs": 0, "goal_ground_truth_calls": 0}
        environment = user.init_environment(suite.load_and_inject_default_environment(effective_map))
        pre = environment.model_copy(deep=True)
        plan_environment = pre.model_copy(deep=True)
        plan_before = snapshot(plan_environment)
        try:
            plan = user.ground_truth(plan_environment)
            plan_error = None
        except Exception as error:
            plan, plan_error = [], type(error).__name__ + ": " + str(error)
        plan_mutated = snapshot(plan_environment) != plan_before
        harness = {"normal_reference_calls": trace_view(plan), "normal_reference_output": user.GROUND_TRUTH_OUTPUT,
                   "reference_generation_error": plan_error, "reference_generation_input_mutated": plan_mutated,
                   "reference_status": "ready" if plan_error is None and not plan_mutated else "pending_reference_generation",
                   "provenance": "Privileged original author reference only; no model inference or semantic-success claim."}
        initial_sha = digest(snapshot(pre))
        bundle = {"pre": pre, "environment": environment, "trace": [], "tool_errors": [], "reference_plan": plan,
                  "reference_status": harness["reference_status"], "reference_output": user.GROUND_TRUTH_OUTPUT,
                  "bound_sources": source_bindings(environment)}
    else:
        payload = Path("input_state.bin.gz").read_bytes()
        if len(payload) > MAX_CAPTURE_BYTES or digest(payload) != request["input_state_sha256"]:
            raise ValueError("Input state bytes/hash mismatch")
        with gzip.GzipFile(fileobj=io.BytesIO(payload)) as stream:
            raw = stream.read(MAX_DECOMPRESSED_BYTES + 1)
        if len(raw) > MAX_DECOMPRESSED_BYTES or digest(raw) != request["input_state_uncompressed_sha256"]:
            raise ValueError("Input state decompression/hash mismatch")
        bundle = pickle.loads(raw)
        if bundle["binding"] != request["expected_binding"]:
            raise ValueError("State lineage mismatch")
        binding = bundle["binding"]
        if (binding["context_id"] != context["context_id"] or binding["catalog_sha256"] != catalog_sha
                or request["sequence"] != binding["sequence"] + 1
                or any(binding[key] != request[key] for key in ["worker_sha256", "assembly_manifest_sha256", "context_manifest_sha256",
                    "condition", "selection_plan_sha256", "source_receipt_sha256", "source_map_sha256", "effective_map_sha256", "argument_helper_sha256"])):
            raise ValueError("Context, source, sequence or catalog mismatch")
        initial_sha = binding["initial_state_sha256"]
        if not isinstance(bundle["environment"], suite.environment_type) or not isinstance(bundle["pre"], suite.environment_type):
            raise TypeError("Original environment class lost on restore")
    before = snapshot(bundle["environment"])
    before_types = digest(encoded(types(bundle["environment"])))
    if request["operation"] != "initialize" and (digest(before) != request["expected_before_json_sha256"]
            or before_types != request["expected_before_types_sha256"]):
        raise ValueError("Restored state/type differs from previous receipt")
    if digest(snapshot(bundle["pre"])) != initial_sha:
        raise ValueError("Retained initial state changed")
    operation_status, tool_outcome, scores = "ok", None, None
    if request["operation"] == "step":
        raw_arguments = copy.deepcopy(request["arguments"])
        call = FunctionCall(function=request["tool_name"], args=copy.deepcopy(raw_arguments))
        coercions = []
        for key, value in call.args.items():
            if isinstance(value, str) and is_string_list(value):
                call.args[key] = literal_eval(value)
                coercions.append(key)
        normalized = copy.deepcopy(call.model_dump(mode="json")["args"])
        invocations = []
        for function in runtime.functions.values():
            function.run = observe_function_entry(function, invocations, encoded)
        bundle["trace"].append(call)
        value, error = runtime.run_function(bundle["environment"], call.function, call.args)
        try:
            formatted, format_error = tool_result_to_str(value), None
        except Exception as failure:
            formatted, format_error = None, type(failure).__name__ + ": " + str(failure)
        matched = [item for item in invocations if item["function"] == call.function]
        observed = matched[-1] if matched else None
        effective = observed["normalized_before_execution"] if observed else None
        tool_outcome = {"function": call.function, "raw_arguments": raw_arguments,
            "normalized_arguments_before_runtime": normalized, "normalized_before_execution": effective,
            "effective_arguments": effective, "effective_arguments_observed": observed is not None,
            "arguments": effective if effective is not None else normalized,
            "post_call_arguments": observed["post_call_arguments"] if observed else None,
            "string_list_coercions": coercions, "original_tool_invocations": invocations,
            "text": formatted, "error": error, "format_error": format_error,
            "source_exposure": source_exposure(value, formatted, call.function, effective)}
        if error is not None or format_error is not None:
            operation_status = "tool_error"
            bundle["tool_errors"].append(tool_outcome)
    elif request["operation"] == "score":
        output = [text_content_block_from_string(request["final_output"])]
        evaluators = {"utility": lambda pre, post, trace: suite._check_user_task_utility(user, output, pre, post, trace)}
        task = next(iter(goals.values()))
        evaluators["goal_success"] = lambda pre, post, trace: suite._check_injection_task_security(task, output, pre, post, trace)
        scores = {}
        for name, evaluator in evaluators.items():
            score, private_before, private_after = evaluate_on_independent_copies(
                evaluator, bundle["pre"], bundle["environment"], bundle["trace"], state_view, trace_view)
            artifacts["predicate_" + name + "_before"] = emit("predicate_" + name + "_before.json.gz", encoded(private_before))
            artifacts["predicate_" + name + "_after"] = emit("predicate_" + name + "_after.json.gz", encoded(private_after))
            scores[name] = score
        if any(score["status"] == "unknown" for score in scores.values()):
            operation_status = "score_unknown"
    elif request["operation"] != "initialize":
        raise ValueError("Unsupported candidate operation")
    after = snapshot(bundle["environment"])
    if digest(snapshot(bundle["pre"])) != initial_sha:
        raise ValueError("Reference or scoring contaminated initial state")
    binding = {"format_version": 1, "context_id": context["context_id"], "sequence": request["sequence"],
               "initial_state_sha256": initial_sha, "parent_receipt_sha256": request["parent_receipt_sha256"],
               "catalog_sha256": catalog_sha,
               "normal_context_id": context["normal_context_id"], "candidate_id": context["context_id"],
               **{key: request[key] for key in ["worker_sha256", "assembly_manifest_sha256", "context_manifest_sha256", "condition",
                   "selection_plan_sha256", "source_receipt_sha256", "source_map_sha256", "effective_map_sha256", "argument_helper_sha256"]}}
    bundle.update(binding=binding)
    raw_state = pickle.dumps(bundle, protocol=5)
    restored = pickle.loads(raw_state)
    after_types = digest(encoded(types(bundle["environment"])))
    if snapshot(restored["environment"]) != after or digest(encoded(types(restored["environment"]))) != after_types:
        raise ValueError("Original typed state roundtrip failed")
    artifacts.update(before=emit("before.json.gz", before), after=emit("after.json.gz", after), state=emit("state.bin.gz", raw_state))
    return {"context_id": context["context_id"], "candidate_id": context["context_id"], "pilot": context["context_id"], "condition": condition,
            "normal_context_id": context["normal_context_id"], "goal_id": context["goal_ids"][0],
            "operation": request["operation"], "operation_status": operation_status,
            "binding": binding, "artifacts": artifacts, "catalog": catalog if harness is not None else None,
            "prompt": user.PROMPT if harness is not None else None, "harness_only": harness,
            "tool_outcome": tool_outcome, "scores": scores, "state_changed": before != after,
            "before_types_sha256": before_types, "after_types_sha256": after_types,
            "trace": trace_view(bundle["trace"]), "prior_tool_errors": bundle["tool_errors"],
            "source_binding_audit": {slot: [{key: value for key, value in field.items() if key != "value"} for field in fields]
                for slot, fields in bundle["bound_sources"].items()} if request["operation"] == "initialize" else None,
            "original_type_roundtrip_passed": True, "model_calls": 0, "payload_generation": 0, "goal_ground_truth_calls": 0}
